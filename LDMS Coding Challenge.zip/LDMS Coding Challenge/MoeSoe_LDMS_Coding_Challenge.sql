
------------------------------------------
-- LDMS Oracle Coding Challenge
-- Moe Soe 08-12-2020
------------------------------------------

DROP TABLE widget_employees;

DROP TABLE widget_departments;

CREATE TABLE widget_departments 
   (	
     department_id       NUMBER(5) NOT NULl,
     department_name     VARCHAR2(50) NOT NULL,
     department_location VARCHAR2(50) NOT NULL,
     CONSTRAINT department_id_pk PRIMARY KEY (department_id)
    );
/
     
INSERT INTO widget_departments (department_id,
                                department_name,
                                department_location)
   VALUES ( 1, 
           'Management', 
           'London');
           
INSERT INTO widget_departments (department_id,
                                department_name,
                                department_location)
   VALUES ( 2, 
           'Engineering', 
           'Cardiff');
           
INSERT INTO widget_departments (department_id,
                                department_name,
                                department_location)
   VALUES ( 3, 
           'Research '||chr(38)||' Development' , 
           'Edinburgh');
           
INSERT INTO widget_departments (department_id,
                                department_name,
                                department_location)
   VALUES ( 4, 
           'Sales' , 
           'Edinburgh');
/
           


CREATE TABLE widget_employees
  (
     employee_id       NUMBER(10) NOT NULL,
     employee_name     VARCHAR2(50) NOT NULL,
     job_title         VARCHAR2(50) NOT NULL,
     manager_id        NUMBER(10),
     date_hired        DATE NOT NULL,
     salary            NUMBER (10) NOT NULL,
     department_id     CONSTRAINT fk_dept_id
                       REFERENCES widget_departments(department_id) 
   );
/

INSERT INTO widget_employees (employee_id,
                              employee_name,
                              job_title,
                              manager_id,
                              date_hired,
                              salary,
                              department_id)
    VALUES (90001, 
            'John Smith', 
            'CEO', 
            NULL,
            TO_DATE ('01/01/95', 'DD/MM/YY'), 
            100000, 
            1);
/
INSERT INTO widget_employees (employee_id,
                              employee_name,
                              job_title,
                              manager_id,
                              date_hired,
                              salary,
                              department_id)
    VALUES (90002, 
            'Jimmy Willis', 
            'Manager',
            90001, 
            TO_DATE ('23/09/03', 'DD/MM/YY'), 
            52500, 
            4);
/    
INSERT INTO widget_employees (employee_id,
                              employee_name,
                              job_title,
                              manager_id,
                              date_hired,
                              salary,
                              department_id)
    VALUES (90003,
            'Roxy Jones', 
            'Salesperson',
            90002,
            TO_DATE ('11/02/17', 'DD/MM/YY'), 
            35000, 
            4);
/
INSERT INTO widget_employees (employee_id,
                              employee_name,
                              job_title,
                              manager_id,
                              date_hired,
                              salary,
                              department_id)
    VALUES (90004,
            'Selwyn Field',
            'Salesperson', 
            90003, 
            TO_DATE ('20/05/15', 'DD/MM/YY'),
            32000, 
            4);
/
INSERT INTO widget_employees (employee_id,
                              employee_name,
                              job_title,
                              manager_id,
                              date_hired,
                              salary,
                              department_id)
    VALUES (90005, 
            'David Hallett', 
            'Engineer',
            90006, 
            TO_DATE ('17/04/18', 'DD/MM/YY'),
            40000, 
            2);
            
INSERT INTO widget_employees (employee_id,
                              employee_name,
                              job_title,
                              manager_id,
                              date_hired,
                              salary,
                              department_id)
    VALUES (90006,
            'Sarah Phelps', 
            'Manager',
            90001,
            TO_DATE ('21/03/15', 'DD/MM/YY'),
            45000, 
            2);
/
INSERT INTO widget_employees (employee_id,
                              employee_name,
                              job_title,
                              manager_id,
                              date_hired,
                              salary,
                              department_id)
    VALUES (90007, 
            'Louise Harper', 
            'Engineer', 
            90006, 
            TO_DATE ('01/01/13', 'DD/MM/YY'), 
            47000, 
            2);
/
INSERT INTO widget_employees (employee_id,
                              employee_name,
                              job_title,
                              manager_id,
                              date_hired,
                              salary,
                              department_id)
    VALUES (90008, 
            'Tina Hart', 
            'Engineer', 
            90009, 
            TO_DATE ('28/07/14', 'DD/MM/YY'), 
            45000, 
            3);
/
INSERT INTO widget_employees (employee_id,
                              employee_name,
                              job_title,
                              manager_id,
                              date_hired,
                              salary,
                              department_id)
    VALUES (90009, 
            'Gus Jones', 
            'Manager', 
            90001, 
            TO_DATE ('15/05/18' , 'DD/MM/YY'),
            50000, 
            3);
/
INSERT INTO widget_employees (employee_id,
                              employee_name,
                              job_title,
                              manager_id,
                              date_hired,
                              salary,
                              department_id)
    VALUES (90010, 
            'Mildred Hall', 
            'Secretary', 
            90001, 
            TO_DATE ('12/10/96' , 'DD/MM/YY'), 
            35000, 
            1);
/
CREATE SEQUENCE employee_id_seq
 START WITH     90011
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;
/



CREATE OR REPLACE PROCEDURE create_new_employee_proc (p_first_name   IN VARCHAR2,
                                                      p_last_name    IN VARCHAR2,
                                                      p_job_title    IN VARCHAR2,
                                                      p_date_hire    IN VARCHAR2,
                                                      p_manager_name IN VARCHAR2,
                                                      p_salary       IN NUMBER,
                                                      p_dept_id      IN NUMBER) IS
                                            
   v_employee_name   VARCHAR2(50);
   v_manager_id      NUMBER(10);
   v_date_hired      DATE;
   v_manager_name    VARCHAR2(50);
                             
                                            
                                            
 BEGIN
 
     v_employee_name := p_first_name || ' ' || p_last_name;
     v_manager_name  := p_manager_name;
     
     SELECT we.employee_id
       INTO v_manager_id
       FROM widget_employees we
      WHERE we.employee_name = v_manager_name;
    
      --DBMS_OUTPUT.PUT_LINE ('Found manager id ' || v_manager_id);
      
     IF SQL%NOTFOUND OR v_manager_id IS NULL THEN
     
        DBMS_OUTPUT.PUT_LINE ( ' No employee is inserted as manager is not correct ');
        
     ELSIF p_dept_id NOT IN (1, 2, 3, 4) THEN
     
        DBMS_OUTPUT.PUT_LINE ( ' No employee is inserted as dept id is not correct ');
        
     ELSE
     
        INSERT INTO widget_employees (employee_id,
                                      employee_name,
                                      job_title,
                                      manager_id,
                                      date_hired,
                                      salary,
                                      department_id)
             VALUES (employee_id_seq.nextval,
                     v_employee_name,
                     p_job_title,
                     v_manager_id,
                     TO_DATE ( p_date_hire, 'DD/MM/YY'),
                     p_salary,
                     p_dept_id);
            
         COMMIT;
         
      END IF;
      
  EXCEPTION
  
      WHEN others THEN
      
        DBMS_OUTPUT.PUT_LINE ( ' Data Errors occured ');
      
  END;
/
  
CREATE OR REPLACE PROCEDURE adjust_salary_proc (p_first_name        IN VARCHAR2,
                                                p_last_name         IN VARCHAR2,
                                                p_decrease_increase IN NUMBER,
                                                p_percentage        IN NUMBER) IS
                                      
    v_employee_name   VARCHAR2(50);  
    v_old_salary      NUMBER(10);
    v_new_salary      NUMBER(10);
    v_employee_id     NUMBER(10);
    
    
 BEGIN
  
    v_employee_name := p_first_name || ' ' || p_last_name;
 
    SELECT we.salary, we.employee_id
      INTO v_old_salary,
           v_employee_id
      FROM widget_employees we
     WHERE we.employee_name = v_employee_name;
 
    IF SQL%NOTFOUND THEN
    
       DBMS_OUTPUT.PUT_LINE ( ' Employee selected does not exist ');
 
    ELSIF p_decrease_increase = 1 THEN
    
         -- Increase the salary
         v_new_salary := v_old_salary + (v_old_salary * ( p_percentage/100));
     
         UPDATE widget_employees
            SET salary = v_new_salary
          WHERE employee_id = v_employee_id
            AND employee_name = v_employee_name;
            
         COMMIT;   
            
    ELSIF p_decrease_increase = 2 THEN
    
          -- decrease the salary
          v_new_salary := v_old_salary - (v_old_salary * ( p_percentage/100));
          
          UPDATE widget_employees
            SET salary = v_new_salary
          WHERE employee_id = v_employee_id
            AND employee_name = v_employee_name;
            
         COMMIT;
    
    
    END IF;
    
END;
/

CREATE OR REPLACE PROCEDURE transfer_employee_proc (p_first_name        IN VARCHAR2,
                                                    p_last_name         IN VARCHAR2,
                                                    p_new_depart_id     IN NUMBER) IS
                                      
    v_employee_name   VARCHAR2(50);  
    v_old_department_id NUMBER(5);
         
 BEGIN
 
    v_employee_name := p_first_name || ' ' || p_last_name;
    
    SELECT we.department_id
      INTO v_old_department_id 
      FROM widget_employees we
     WHERE we.employee_name = v_employee_name;
     
    IF SQL%NOTFOUND THEN
    
       DBMS_OUTPUT.PUT_LINE ( ' Employee selected does not exist ');
       
    ELSIF v_old_department_id !=  p_new_depart_id OR p_new_depart_id IN (1,2,3,4) THEN
    
       
         UPDATE widget_employees
            SET department_id = p_new_depart_id
          WHERE employee_name = v_employee_name;
            
         COMMIT;
         
    ELSIF v_old_department_id =  p_new_depart_id THEN
    
       DBMS_OUTPUT.PUT_LINE ( ' New Employee department is same as old one ');
       
    ELSIF p_new_depart_id NOT IN (1,2,3,4) THEN 
    
       DBMS_OUTPUT.PUT_LINE ( ' New Employee department is not valid ');
         
   END IF;
   
  END;
/
                                            

CREATE OR REPLACE PROCEDURE display_employee_sal_proc (p_first_name        IN VARCHAR2,
                                                       p_last_name         IN VARCHAR2) IS  
                                             
   v_employee_name   VARCHAR2(50);
   v_employee_salary NUMBER(10);
   
 BEGIN
 
   v_employee_name := p_first_name || ' ' || p_last_name;
              
    SELECT we.salary
      INTO v_employee_salary 
      FROM widget_employees we
     WHERE we.employee_name = v_employee_name;   
     
    IF SQL%NOTFOUND THEN
    
       DBMS_OUTPUT.PUT_LINE ( ' Employee selected does not exist ');
       
    ELSE
    
      DBMS_OUTPUT.PUT_LINE ( ' Employee '|| v_employee_name ||' Salary is ' || v_employee_salary);
      
    END IF;
    
END;
/

CREATE OR REPLACE PROCEDURE display_dept_employee_proc (p_dept_id IN NUMBER ) IS

  
  TYPE employee_type IS TABLE OF widget_employees%ROWTYPE INDEX BY PLS_INTEGER;
  
  v_employee_rec employee_type;
  
  
 BEGIN
 
    SELECT *
    BULK COLLECT INTO v_employee_rec
    FROM widget_employees
    WHERE department_id = p_dept_id;
    
    FOR indx IN 1 .. v_employee_rec.COUNT
       LOOP
       
        DBMS_OUTPUT.PUT_LINE (' Employee id - '|| v_employee_rec(indx).employee_id || ' Employee Name - ' || v_employee_rec(indx).employee_name || ' Job_title - ' || v_employee_rec(indx).job_title || 
        ' Manager Id - ' || v_employee_rec(indx).manager_id ||' Date Hired - ' || v_employee_rec(indx).date_hired||' Salary - '||v_employee_rec(indx).salary||' Dept id - '||v_employee_rec(indx).department_id);
       
       END LOOP;
       
 END;
/

CREATE OR REPLACE PROCEDURE show_tot_salary_proc (p_dept_id IN NUMBER ) IS

  v_total_salary NUMBER(10);
  
BEGIN

   SELECT SUM(salary)
     INTO v_total_salary
     FROM widget_employees
    WHERE department_id = p_dept_id;
    
    IF SQL%NOTFOUND THEN
    
       DBMS_OUTPUT.PUT_LINE ( ' Department selected does not exist ');
       
    ELSE
    
      DBMS_OUTPUT.PUT_LINE ( ' Total salary for department is = ' || v_total_salary);
      
    END IF;
    
    
END;
/



       
         
 