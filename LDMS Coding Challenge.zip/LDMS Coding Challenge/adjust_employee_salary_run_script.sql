

SET SERVEROUTPUT ON; 

  PROMPT ' 2. Adjust Employee Salary ';
  
  ACCEPT v_employee_first_name CHAR PROMPT ' Please enter employee first name';
  
  ACCEPT v_employee_surname CHAR PROMPT ' Please enter employee surname';
  
  ACCEPT v_decrease_increase NUMBER PROMPT ' Please enter value 1 to decrease employee salary or value 2 to increase employee salary ';
  
  ACCEPT v_percentage NUMBER PROMPT ' Please enter percentage value between 1 - 99 to increase or decrease salary ';
     
DECLARE

  l_employee_first_name VARCHAR2(25) := '&v_employee_first_name';
  l_employee_surname    VARCHAR2(25) := '&v_employee_surname';
  l_decrease_increase   NUMBER(5)    := '&v_decrease_increase';
  l_percentage          NUMBER(10)   := '&v_percentage';
     
BEGIN 

  adjust_salary_proc (l_employee_first_name,
                      l_employee_surname, 
                      l_decrease_increase,
                      l_percentage);

END;
