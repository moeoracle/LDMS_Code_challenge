

SET SERVEROUTPUT ON; 

  PROMPT 'Create New employee ';
  
  ACCEPT v_employee_first_name CHAR PROMPT ' Please enter employee first name';
  
  ACCEPT v_employee_surname CHAR PROMPT ' Please enter employee surname';
  
  ACCEPT v_job_title CHAR PROMPT ' Please enter employee job title ';
  
  ACCEPT v_manager_first_name CHAR PROMPT ' Please enter manager first name';
  
  ACCEPT v_manager_surname CHAR PROMPT ' Please enter manager surname';
  
  ACCEPT v_date_hired CHAR PROMPT ' Please enter hiring date in the format DD/MM/YY ';
  
  ACCEPT v_salary NUMBER PROMPT ' Please enter employee salary ';
  
  ACCEPT v_dept_id NUMBER PROMPT 'Please enter department id value of 1, 2, 3 or 4 ';
     
DECLARE

  l_employee_first_name VARCHAR2(25) := '&v_employee_first_name';
  l_employee_surname    VARCHAR2(25) := '&v_employee_surname';
  l_job_title           VARCHAR2(50) := '&v_job_title';
  l_date_hired          VARCHAR2(10) := '&v_date_hired';
  l_salary              NUMBER(10)   := '&v_salary';
  l_dept_id             NUMBER(5)    := '&v_dept_id';
  
  l_manager_name        VARCHAR2(50);
     
BEGIN 
 
   l_manager_name := '&v_manager_first_name'||' '||'&v_manager_surname';

  create_new_employee_proc (l_employee_first_name, 
                            l_employee_surname,
                            l_job_title, 
                            l_date_hired,
                            l_manager_name,
                            l_salary, 
                            l_dept_id );
   
END;