

SET SERVEROUTPUT ON; 
          
  PROMPT ' 4. Show Salary of employee';
     
  ACCEPT v_employee_first_name CHAR PROMPT ' Please enter employee first name';
  
  ACCEPT v_employee_surname CHAR PROMPT ' Please enter employee surname';
     
DECLARE

  l_employee_first_name VARCHAR2(25) := '&v_employee_first_name';
  l_employee_surname    VARCHAR2(25) := '&v_employee_surname';
     
BEGIN 

  display_employee_sal_proc (l_employee_first_name, 
                             l_employee_surname);

END;
