

SET SERVEROUTPUT ON; 

     
  PROMPT ' 6. Print total of Employees Salary for a Department ';
  
  ACCEPT v_department_id NUMBER PROMPT ' Please select department id for report :- 1 for MANAGEMENT, 2 for ENGINEERING, 3 for RESEARCH and DEVELOPMENT and 4 for SALES ';
     
DECLARE

  l_department_id NUMBER(5) := '&v_department_id';
     
BEGIN 

  show_tot_salary_proc (l_department_id);

END;
