

SET SERVEROUTPUT ON; 

     
  PROMPT ' 5. Print all Employees in a department ';
     
  ACCEPT v_department_id NUMBER PROMPT ' Please select department id for report :- 1 for MANAGEMENT, 2 for ENGINEERING, 3 for RESEARCH and DEVELOPMENT and 4 for SALES ';
     
DECLARE

  l_department_id NUMBER(5) := '&v_department_id';
     
BEGIN 

  display_dept_employee_proc (l_department_id);

END;
