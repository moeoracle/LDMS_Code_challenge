

SET SERVEROUTPUT ON; 
     
  PROMPT ' 3. Transfer Employee to different Department ';
          
  ACCEPT v_employee_first_name CHAR PROMPT ' Please enter employee first name';
  
  ACCEPT v_employee_surname CHAR PROMPT ' Please enter employee surname';
  
  ACCEPT v_new_department NUMBER PROMPT ' Please select new department :- 1 for MANAGEMENT, 2 for ENGINEERING, 3 for RESEARCH and DEVELOPMENT and 4 for SALES ';
     
DECLARE

  l_employee_first_name VARCHAR2(25) := '&v_employee_first_name';
  l_employee_surname    VARCHAR2(25) := '&v_employee_surname';
  l_new_department      NUMBER(5)    := '&v_new_department';
     
BEGIN 

  transfer_employee_proc (l_employee_first_name, 
                          l_employee_surname, 
                          l_new_department);

END;
